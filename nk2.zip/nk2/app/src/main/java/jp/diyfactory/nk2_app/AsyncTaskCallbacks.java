package jp.diyfactory.nk2_app;

public interface AsyncTaskCallbacks {
    public void onTaskFinished();   // 終了
    public void onTaskCancelled();  // キャンセル
}
