package jp.diyfactory.nk2_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class JPSizeRegister extends AppCompatActivity implements TextWatcher, View.OnClickListener, AsyncTaskCallbacks{
    EditText edtInquiryNo;
    EditText edtSize;
    Switch swtContinues;
    Button btnRigister;
    Button btnReset;
    String sSize = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jp_size_register);
        edtInquiryNo = findViewById(R.id.edtInquiryNo);
        swtContinues = (Switch)findViewById(R.id.swtContinues);
        swtContinues.setChecked(true);
        swtContinues.setOnClickListener(this);
        edtSize = findViewById(R.id.edtSize);
        btnReset = findViewById(R.id.btnReset);
        btnReset.setOnClickListener(this);
        edtInquiryNo.addTextChangedListener(this);
        edtSize.addTextChangedListener(this);
        edtSize.requestFocus();
    }

    @Override
    public void onClick(View v) {
        if(v == btnReset){
            sSize = "";
            edtInquiryNo.setText("");
            edtSize.setText("");
            edtSize.setEnabled(true);
            edtSize.requestFocus();
            sSize = null;
        }else if(v == swtContinues){
            sSize = "";
            edtSize.setText("");
            edtSize.setEnabled(true);
            edtSize.requestFocus();

        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        if(edtInquiryNo.isFocused()){
            String sInquiryNo = edtInquiryNo.getText().toString();
            int iInquiryLen = sInquiryNo.length();
            if(iInquiryLen > 0 && !sSize.isEmpty()) {
                new MySqlUpdateSize(this, this ).execute( sInquiryNo, sSize);
                edtInquiryNo.setText("");
            }else{
               // edtInquiryNo.setText("");
                //edtInquiryNo.requestFocus();
            }
        }else if(edtSize.isFocused()){
            String sSizeCd = edtSize.getText().toString();
            if(sSizeCd.length() > 0) {
                if (sSizeCd.equals("060")) {
                    sSize = "60";
                } else if (sSizeCd.equals("080")) {
                    sSize = "80";
                } else if (sSizeCd.equals("1005")) {
                    sSize = "100";
                } else if (sSizeCd.equals("1207")) {
                    sSize = "120";
                } else if (sSizeCd.equals("1409")) {
                    sSize = "140";
                } else if (sSizeCd.equals("160")) {
                    sSize = "160";
                } else if (sSizeCd.equals("170")) {
                    sSize = "170";
                } else {
                    sSize = "60";
                }
            }
            if(sSize.length() > 0) {
                if(swtContinues.isChecked()) {
                    edtSize.setEnabled(false);
                    //edtSize.setText(sSize);
                }
                edtInquiryNo.requestFocus();
                edtSize.setText(sSize);
            }else{
                edtSize.requestFocus();
            }
        }
    }

    @Override
    public void onTaskFinished() {
        // TODO Auto-generated method stub
        SharedPreferences data = this.getSharedPreferences("DataSave", this.MODE_PRIVATE);
        int iResult = data.getInt("CallBack",0 );
        if(iResult < 0){
            new AlertDialog.Builder(this)
                    .setTitle("警告")
                    .setMessage("この送り状番号でサイズが登録できません。")
                    .setCancelable(false)
                    .setPositiveButton("はい", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).show();
            edtInquiryNo.setText("");
            edtInquiryNo.requestFocus();
        }else{
            if(swtContinues.isChecked()){
                edtInquiryNo.requestFocus();
            }else {
                edtSize.setText("");
                edtSize.requestFocus();
            }

        }
    }

    @Override
    public void onTaskCancelled() {

    }
}