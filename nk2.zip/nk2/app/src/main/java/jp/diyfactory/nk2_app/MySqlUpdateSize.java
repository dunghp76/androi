package jp.diyfactory.nk2_app;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import static android.content.ContentValues.TAG;

public class MySqlUpdateSize extends AsyncTask<String, String, Integer> {
    private AsyncTaskCallbacks callback = null;
    ProgressDialog dialog;
    Context context;

    public MySqlUpdateSize(Context context, AsyncTaskCallbacks callback){
        this.context = context;
        this.callback = callback;
    }
    @Override
    protected void onPreExecute() {
        Log.d(TAG, "onPreExecute");
        dialog = new ProgressDialog(context);
        dialog.setTitle("少々お待ちください。");
        dialog.setMessage("データローディング...");
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.setMax(100);
        dialog.setProgress(0);
        dialog.show();
    }
    @Override
    protected Integer doInBackground(String... inPara) {
        int iResult = 1;
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String sDeliDate = sdf.format(date);
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://mysql-test-gufu.cqnq0j3be4gt.ap-northeast-1.rds.amazonaws.com:3306","daito_db","ofe!vb8w5q8)p4ppl1j0(gc!jrsl");
            //Connection conn=DriverManager.getConnection("jdbc:mysql://edi-staging.cqnq0j3be4gt.ap-northeast-1.rds.amazonaws.com:3306","daito_db","ofe!vb8w5q8)p4ppl1j0(gc!jrsl");
            conn.setAutoCommit(false);
            Statement stmt=conn.createStatement();
            String sqlModel="UPDATE nk2.dt_shipping AS a " +
                    "JOIN nk2.dt_multi_pack_inquiry AS b " +
                    "ON a.deli_index = b.deli_index " +
                    "SET b.package_size = " + inPara[1] + ", " +
                    "a.up_date = \'" + date + "\', " +
                    "a.up_ope_cd = \'DEV00001\' " +
                    " WHERE b.inquiry_no =  \'" + inPara[0] + "\' " +
                    "AND a.deli_date = \'" + sDeliDate  + "\' " +
                    "AND a.delivery_code = 4 " +
                    "AND a.process_status = 2 AND a.is_sync = 0 ";
            try {
                int rsModel = stmt.executeUpdate(sqlModel);
                if(rsModel < 1 ){
                    conn.rollback();
                    iResult = -1;
                }else{
                    conn.commit();
                    iResult = 1;
                }
            }catch (SQLException e){
                conn.rollback();
                iResult = -1;
            }
            stmt.close();
            conn.close();
        }catch(Exception e){
            e.getMessage();
            iResult = -1;
        }
        return iResult;
    }
    /**
     * バックグランド処理が完了し、UIスレッドに反映する
     */
    @Override
    protected void onPostExecute(Integer result) {
        //this.txtPC.setText(proInfo.getsProductCode());
        SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
        SharedPreferences.Editor editor = data.edit();
        if(result > 0) {
            editor.putInt("CallBack", result);
            editor.apply();
        }else{
            editor.putInt("CallBack", result);
            editor.apply();
        }
        //Log.d(TAG, "onPostExecute - " + proInfo);
        dialog.dismiss();
        callback.onTaskFinished();
        dialog.dismiss();
    }
}
