package jp.diyfactory.nk2_app;

public class ReceiveProductInfo {
    private String sRequestNum = "";
    private String sRequestLine = "";
    private String sSupName = "";
    private  int iSupCode = 0;
    private String sMakerCode = "";
    private String sProductCode = "";
    private String sShelfNo = "";
    private int iPlanQ = 0;
    private int iRealQ = 0;
    private int iStockNum = 0;

    public ReceiveProductInfo(){
        sRequestNum = "";
        sRequestLine = "";
        sSupName = "";
        sMakerCode = "";
        sProductCode = "";
        sShelfNo = "";
        iPlanQ = 0;
        iRealQ = 0;
        iStockNum = 0;
    }

    public ReceiveProductInfo(String requestNum, String requestLine, String supName, int supCode ,
                              String proCode, String makerCode, String shelfNo, int planQ, int realQ,int stockNum){
        sRequestNum = requestNum;
        sRequestLine = requestLine;
        sSupName = supName;
        iSupCode = supCode;
        sMakerCode = makerCode;
        sProductCode = proCode;
        sShelfNo = shelfNo;
        iPlanQ = planQ;
        iRealQ = realQ;
        iStockNum = stockNum;
    }

    public String getsSupName() {
        return sSupName;
    }

    public void setiSupCode(int iSupCode) {
        this.iSupCode = iSupCode;
    }

    public String getsRequestLine() {
        return sRequestLine;
    }

    public void setsRequestLine(String sRequestLine) {
        this.sRequestLine = sRequestLine;
    }

    public int getiSupCode() {
        return iSupCode;
    }

    public void setsSupName(String sSupName) {
        this.sSupName = sSupName;
    }

    public int getiPlanQ() {
        return iPlanQ;
    }

    public void setiPlanQ(int iPlanQ) {
        this.iPlanQ = iPlanQ;
    }

    public int getiStockNum() {
        return iStockNum;
    }

    public void setiStockNum(int iStockNum) {
        this.iStockNum = iStockNum;
    }

    public void setsMakerCode(String productCode){
        this.sMakerCode = productCode;
    }

    public void setsProductCode(String sProductCode) {
        this.sProductCode = sProductCode;
    }

    public void setsShelfNo(String shelfNo){
        this.sShelfNo = shelfNo;
    }

    public String getsMakerCode(){
        return this.sMakerCode;
    }

    public String getsProductCode() {
        return sProductCode;
    }

    public String getsShelfNo(){
        return this.sShelfNo;
    }

    public String getsRequestNum(){return this.sRequestNum;}

    public void setsRequestNum(String sRequestNum) {
        this.sRequestNum = sRequestNum;
    }

    public int getiRealQ() {
        return iRealQ;
    }

    public void setiRealQ(int iRealQ) {
        this.iRealQ = iRealQ;
    }
}
