package jp.diyfactory.nk2_app;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import static android.content.ContentValues.TAG;

public class MySqlSelectReceiveData extends AsyncTask<String, String, ReceiveProductInfo> {
    private AsyncTaskCallbacks callback = null;
    ProgressDialog dialog;
    private Context context;
    private TextView txtSupName;
    private TextView txtMC;
    private TextView txtSN;
    private TextView txtQA;
    private TextView txtStockNum;

    public MySqlSelectReceiveData(Context context, AsyncTaskCallbacks callback, TextView supName,
                                  TextView makerCode, TextView shelfNo, TextView quantity, TextView stockNum){
        this.callback = callback;
        this.context = context;
        this.txtSupName = supName;
        this.txtMC = makerCode;
        this.txtSN = shelfNo;
        this.txtQA = quantity;
        this.txtStockNum = stockNum;
    }
    @Override
    protected void onPreExecute() {
        Log.d(TAG, "onPreExecute");
        dialog = new ProgressDialog(context);
        dialog.setTitle("少々お待ちください。");
        dialog.setMessage("データローディング...");
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.setMax(100);
        dialog.setProgress(0);
        dialog.show();
    }
    @Override
    protected ReceiveProductInfo doInBackground(String... inPara) {
        int iResult = 1;
        ReceiveProductInfo receiveInfo = null;
        DateFormat df = new SimpleDateFormat("yyyyMMdd");
        Date date = new Date(System.currentTimeMillis());
        String ReceiveDate = df.format(date);
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn= DriverManager.getConnection("jdbc:mysql://mysql-test-gufu.cqnq0j3be4gt.ap-northeast-1.rds.amazonaws.com:3306","daito_db","ofe!vb8w5q8)p4ppl1j0(gc!jrsl");
            Statement stmt=conn.createStatement();
            String sql="SELECT a.request_num, a.request_line_num, a.supplier_id, a.plan_quantity, " +
                    "b.product_code, b.shelf_no,b.stock_num, c.supplier_nm, a.maker_num, a.quantity " +
                    "FROM nk2.dt_request_model AS a " +
                    "JOIN nk2.mst_product_stock AS b " +
                    "ON a.product_code = b.product_code \n" +
                    "JOIN nk2.mst_supplier AS c \n" +
                    "ON a.supplier_id = c.supplier_cd \n" +
                    "WHERE a.product_jan = \'" + inPara[0] + "\' " +
                    "AND a.is_closedoc = 0 \n" +
                    "AND a.arrival_plan_date = \'" + ReceiveDate + "\' \n" +
                    "AND a.process_status < 2 \n" +
                    "LIMIT 1 ";
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next()) {
                receiveInfo = new ReceiveProductInfo(rs.getString("request_num"),
                        rs.getString("request_line_num"),
                        rs.getString("supplier_nm"),
                        rs.getInt("supplier_id"),
                        rs.getString("product_code"),
                        rs.getString("maker_num"),
                        rs.getString("shelf_no"),
                        rs.getInt("plan_quantity"),
                        rs.getInt("quantity"),
                        rs.getInt("stock_num"));
            }else{
                receiveInfo = null;
            }
            rs.close();
            stmt.close();
            conn.close();
        }catch(Exception e){
            e.getMessage();
            receiveInfo = null;
        }
        return receiveInfo;
    }
    /**
     * バックグランド処理が完了し、UIスレッドに反映する
     */
    @Override
    protected void onPostExecute(ReceiveProductInfo recInfo) {
        //this.txtPC.setText(proInfo.getsProductCode());
        if(recInfo != null) {
            String supName = recInfo.getsSupName();
            String shelfNo = recInfo.getsShelfNo();
            String planQ = String.valueOf(recInfo.getiPlanQ() - recInfo.getiRealQ());
            int realQ = recInfo.getiRealQ();
            String makerCode = recInfo.getsMakerCode();
            String stockNum = String.valueOf(recInfo.getiStockNum());
            String productCode = recInfo.getsProductCode();
            String requestNum = recInfo.getsRequestNum();
            String requestLine = recInfo.getsRequestLine();
            int supId = recInfo.getiSupCode();
            this.txtSupName.setText(supName.toString());
            this.txtMC.setText(makerCode.toString());
            this.txtSN.setText(shelfNo.toString());
            this.txtQA.setText(planQ.toString());
            this.txtStockNum.setText(stockNum.toString());
            SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
            SharedPreferences.Editor editor = data.edit();
            editor.putString("ProductCode", productCode.toString());
            editor.putString("RequestNum", requestNum.toString());
            editor.putString("RequestLine", requestLine.toString());
            editor.putInt("SupplierID", supId);
            editor.putInt("RealQua", realQ);
            editor.putInt("StockNum", Integer.valueOf(stockNum));
            editor.putInt("CallBack", 0);
            editor.apply();
        }else{
            SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
            SharedPreferences.Editor editor = data.edit();
            editor.putInt("CallBack", -1);
            editor.apply();
        }
        //Log.d(TAG, "onPostExecute - " + proInfo);
        dialog.dismiss();
        callback.onTaskFinished();
    }

    @Override
    protected void onCancelled() {
        // TODO Auto-generated method stub
        Log.v("AsyncTask", "onCancelled");
        callback.onTaskCancelled();
    }
}
