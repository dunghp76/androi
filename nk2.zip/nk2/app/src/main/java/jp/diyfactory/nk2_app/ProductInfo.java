package jp.diyfactory.nk2_app;

public class ProductInfo {
    private String sMakerCode = "";
    private String sProductCode = "";
    private String sShelfNo = "";
    private int iQuantity = 0;

    public ProductInfo(){
        sProductCode = "";
        sMakerCode = "";
        sShelfNo = "";
        iQuantity = 0;
    }

    public ProductInfo(String proCode, String makerCode, String shelfNo, int quantity){
        sMakerCode = makerCode;
        sProductCode = proCode;
        sShelfNo = shelfNo;
        iQuantity = quantity;
    }

    public void setsMakerCode(String productCode){
        this.sMakerCode = productCode;
    }

    public void setsProductCode(String sProductCode) {
        this.sProductCode = sProductCode;
    }

    public String getsProductCode() {
        return sProductCode;
    }

    public void setsShelfNo(String shelfNo){
        this.sShelfNo = shelfNo;
    }

    public void setiQuantity(int quantity){
        this.iQuantity = quantity;
    }

    public String getsMakerCode(){
        return this.sMakerCode;
    }

    public String getsShelfNo(){
        return this.sShelfNo;
    }

    public int getiQuantity() {
        return this.iQuantity;
    }
}
