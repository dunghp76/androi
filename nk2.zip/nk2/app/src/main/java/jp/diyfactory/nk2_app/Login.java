package jp.diyfactory.nk2_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity implements TextWatcher, View.OnClickListener{
    EditText edtID;
    EditText edtPass;
    TextView txtError;
    Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        edtID = findViewById(R.id.edtID);
        edtPass = findViewById(R.id.edtPass);
        btnLogin = findViewById(R.id.btnLogin);
        txtError = findViewById(R.id.txtError);
        edtID.requestFocus();
        edtID.addTextChangedListener(this);
        edtPass.addTextChangedListener(this);
        btnLogin.setOnClickListener(this);
        btnLogin.setEnabled(false);
        txtError.setVisibility(View.INVISIBLE);
        SharedPreferences data = this.getSharedPreferences("DataSave", this.MODE_PRIVATE);
        SharedPreferences.Editor editor = data.edit();
        editor.putString("UserID", "DEV00001");
        editor.putString("Password", "Device001");
        editor.apply();
    }

    public void onClick(View view){
        if(view == btnLogin) {
            SharedPreferences data = this.getSharedPreferences("DataSave", this.MODE_PRIVATE);
            String sUserId = data.getString("UserID", "");
            String sPassW = data.getString("Password", "");
            String sID = edtID.getText().toString();
            String sPass = edtPass.getText().toString();
            if(sID.trim().equals(sUserId.toString()) && sPass.trim().equals(sPassW.toString())){
                Intent intent = new Intent(this, MenuActivity.class);
                startActivity(intent);
                finish();
            }else{
                edtID.setText("");
                edtPass.setText("");
                txtError.setVisibility(View.VISIBLE);
                edtID.requestFocus();
            }
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        //txtJan.setText("");
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
        // テキスト変更後に変更されたテキストを取り出す
        String sPassW = "";
        boolean bCon = false;
        if(edtID.isFocused()){
            String sID = edtID.getText().toString();
            if(!sID.trim().equals("")) {
                int iIndex = sID.indexOf("-");
                if(iIndex > 0) {
                    sPassW = sID.substring(iIndex + 1);
                    sID = sID.substring(0, iIndex);
                    edtID.setText(sID);
                    edtPass.setText(sPassW);
                    btnLogin.setEnabled(true);
                    btnLogin.requestFocus();
                    SharedPreferences data = this.getSharedPreferences("DataSave", this.MODE_PRIVATE);
                    String sUserId = data.getString("UserID", "");
                    String sPass = data.getString("Password", "");
                    if(sID.trim().equals(sUserId.toString()) && sPass.trim().equals(sPassW.toString())) {
                        Intent intent = new Intent(this, MenuActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }else{
                    //edtPass.requestFocus();
                }
            }
        }else if(edtPass.isFocused()){
            String sID = edtID.getText().toString();
            String sPass = edtPass.getText().toString();
            if(!sID.trim().equals("") && !sPass.trim().equals("")){
                btnLogin.setEnabled(true);
                //btnLogin.requestFocus();
            }
        }
    }
}
