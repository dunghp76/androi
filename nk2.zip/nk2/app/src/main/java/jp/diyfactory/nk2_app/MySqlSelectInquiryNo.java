package jp.diyfactory.nk2_app;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import static android.content.ContentValues.TAG;

public class MySqlSelectInquiryNo extends AsyncTask<String, String, String> {
    private AsyncTaskCallbacks callback = null;
    ProgressDialog dialog;
    private Context context;
    private TextView txtNowSize;
    private TextView txtMC;
    private TextView txtSN;
    private TextView txtQA;
    private TextView txtStockNum;

    public MySqlSelectInquiryNo(Context context, AsyncTaskCallbacks callback, TextView txtSize){
        this.callback = callback;
        this.context = context;
        this.txtNowSize = txtSize;
    }
    @Override
    protected void onPreExecute() {
        Log.d(TAG, "onPreExecute");
        dialog = new ProgressDialog(context);
        dialog.setTitle("少々お待ちください。");
        dialog.setMessage("データローディング...");
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.setMax(100);
        dialog.setProgress(0);
        dialog.show();
    }
    @Override
    protected String doInBackground(String... inPara) {
        int iResult = 1;
        String sNowSize = null;
        DateFormat df = new SimpleDateFormat("yyyyMMdd");
        Date date = new Date(System.currentTimeMillis());
        String DeliDate = df.format(date);
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn= DriverManager.getConnection("jdbc:mysql://mysql-test-gufu.cqnq0j3be4gt.ap-northeast-1.rds.amazonaws.com:3306","daito_db","ofe!vb8w5q8)p4ppl1j0(gc!jrsl");
            //Connection conn=DriverManager.getConnection("jdbc:mysql://edi-staging.cqnq0j3be4gt.ap-northeast-1.rds.amazonaws.com:3306","daito_db","ofe!vb8w5q8)p4ppl1j0(gc!jrsl");
            Statement stmt=conn.createStatement();
            String sql="SELECT a.package_size " +
                    "FROM nk2.dt_shipping AS a " +
                    "WHERE a.inquiry_no = \'" + inPara[0] + "\' " +
                    "AND a.delivery_code = 4 " +
                    "AND a.deli_date = \'" + DeliDate + "\' " +
                    "AND a.is_sync = 0 AND a.process_status = 2 ";
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next()) {
                sNowSize = rs.getString("package_size");
            }else{
                sNowSize = null;
            }
            rs.close();
            stmt.close();
            conn.close();
        }catch(Exception e){
            e.getMessage();
            sNowSize = null;
        }
        return sNowSize;
    }
    /**
     * バックグランド処理が完了し、UIスレッドに反映する
     */
    @Override
    protected void onPostExecute(String nowSize) {
        //this.txtPC.setText(proInfo.getsProductCode());
        SharedPreferences data = context.getSharedPreferences("DataSave", context.MODE_PRIVATE);
        SharedPreferences.Editor editor = data.edit();
        if(nowSize != null) {
            this.txtNowSize.setText(nowSize.toString());
            editor.putInt("CallBack", 1);
            editor.apply();
        }else{
            editor.putInt("CallBack", -1);
            editor.apply();
        }
        //Log.d(TAG, "onPostExecute - " + proInfo);
        dialog.dismiss();
        callback.onTaskFinished();
    }

    @Override
    protected void onCancelled() {
        // TODO Auto-generated method stub
        Log.v("AsyncTask", "onCancelled");
        callback.onTaskCancelled();
    }
}
